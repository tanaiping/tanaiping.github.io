<template>
  <div class="community">
     <router-view />
  </div>
</template>

<script>
</script>

<style>
</style>
